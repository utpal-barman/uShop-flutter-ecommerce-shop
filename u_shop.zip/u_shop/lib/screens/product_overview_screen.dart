import 'package:flutter/material.dart';
import 'package:u_shop/widgets/products_grid.dart';

class ProductOverviewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ProductsGrid();
  }
}
